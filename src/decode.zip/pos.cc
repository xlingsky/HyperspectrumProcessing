#include "pos.h"
#include "decode.h"

#include <gdal_alg.h>
#include <gdal_alg_priv.h>
#include <cpl_error.h>
#include <ogr_spatialref.h>
#include <ogr_srs_api.h>

namespace PosParse{

bool MARK1PVAA(const char* msg, HSP::Pos::record& rec){
  const char* p = strrchr(msg, ';');
  if (p==nullptr) return false;

  if( sscanf(p+1, "%u%*c%lf%*c%lf%*c%lf%*c%lf%*c%lf%*c%lf%*c%lf%*c%lf%*c%lf%*c%lf"
             , &rec.week, &rec.time
             , rec.blh, rec.blh+1, rec.blh+2
             , rec.vx, rec.vx+1, rec.vx+2
             , rec.a, rec.a+1, rec.a+2
             ) != 11){
    return false;
  }

  return true;
}

};

namespace HSP{

Pos::~Pos(){
  if(_reprojection)
    GDALDestroyTransformer(_reprojection);
}

bool Pos::load(const char *filepath){
  const char* ext = strrchr(filepath, '.');

  if(ext==nullptr)
    return false;

  if(strcmp(ext+1, "aux")==0)
    return LoadAux(filepath);

  return false;
}

bool Pos::LoadAux(const char *filepath) {
  FILE* fp = fopen(filepath, "r");

  std::map<int, record> pos_data;

  int line = 0;
  std::vector<char> last_pos;
  while(1){
    int frame, count;
    if(fread(&frame, sizeof(int), 1, fp)!=1) break;
    if(fread(&count, sizeof(int), 1, fp)!=1) break;
    if(count==0) continue;
    std::vector<char> buffer(count);
    if(fread(buffer.data(), sizeof(char), count, fp)!=count) break;

    std::vector<char> pos(count*2.0/3);
    HSP::cvt_12to16( buffer.data(), count, pos.begin());
    if(pos.size()!=last_pos.size() || memcmp(&pos[0], &last_pos[0], pos.size())!=0){
      last_pos = pos;
      record rec;
      if(PosParse::MARK1PVAA(pos.data(), rec)){
        rec.frame = frame;
        pos_data.insert({line,rec});
      }
    }
    ++line;
  }

  if(pos_data.size()>0) std::swap(_data, pos_data);

  fclose(fp);
  return true;
}

void Pos::Reprojection(){
  if(!_reprojection){
    
  }
}

};
