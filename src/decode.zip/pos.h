#ifndef POS_H
#define POS_H

#include <vector>
#include <map>

namespace HSP{

class Pos{
 public:
  struct record{
    unsigned int frame;
    unsigned int week;
    double time;
    double blh[3];
    double x[3];
    double vx[3];
    double a[3];
  };

 protected:
  std::map<int, record> _data;
  void* _reprojection;
 public:
  Pos() : _reprojection(nullptr) {
  }
  ~Pos();
  bool load(const char* filepath);
  size_t size() const { return _data.size(); }
  record& front() { return _data.begin()->second; }
  record& back() { return  _data.rbegin()->second; }
 private:
  void Reprojection();
  bool LoadAux(const char* filepath);
};

class View{
 public:
};

};

#endif
